//
//  PlanningModel.swift
//  PlanningPro
//
//  Created by Soumitra MacBook on 19/06/21.
//

import Foundation

struct PlanningResponseModel : Codable {
    let status : Bool?
    let code : Int?
    let data : [PlanData]?
    let message : String?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case code = "code"
        case data = "data"
        case message = "message"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decodeIfPresent(Bool.self, forKey: .status)
        code = try values.decodeIfPresent(Int.self, forKey: .code)
        data = try values.decodeIfPresent([PlanData].self, forKey: .data)
        message = try values.decodeIfPresent(String.self, forKey: .message)
    }

}
struct PlanData : Codable {
    let id : Int?
    let role_name : String?
    let role_type : Int?
    let company : String?
    let colour : String?
    let order : String?
    let user_id : Int?
    let created_at : String?
    let updated_at : String?
    let deleted_at : String?
    let planning : Planning?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case role_name = "role_name"
        case role_type = "role_type"
        case company = "company"
        case colour = "colour"
        case order = "order"
        case user_id = "user_id"
        case created_at = "created_at"
        case updated_at = "updated_at"
        case deleted_at = "deleted_at"
        case planning = "planning"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        role_name = try values.decodeIfPresent(String.self, forKey: .role_name)
        role_type = try values.decodeIfPresent(Int.self, forKey: .role_type)
        company = try values.decodeIfPresent(String.self, forKey: .company)
        colour = try values.decodeIfPresent(String.self, forKey: .colour)
        order = try values.decodeIfPresent(String.self, forKey: .order)
        user_id = try values.decodeIfPresent(Int.self, forKey: .user_id)
        created_at = try values.decodeIfPresent(String.self, forKey: .created_at)
        updated_at = try values.decodeIfPresent(String.self, forKey: .updated_at)
        deleted_at = try values.decodeIfPresent(String.self, forKey: .deleted_at)
        planning = try values.decodeIfPresent(Planning.self, forKey: .planning)
    }

}
struct Planning : Codable {
    let id : Int?
    let mission : String?
    let vision : String?
    let type : Int?
    let client_role_id : Int?
    let year : String?
    let quarter : String?
    let created_at : String?
    let updated_at : String?
    let deleted_at : String?
    let objective : [PlanObjective]?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case mission = "mission"
        case vision = "vision"
        case type = "type"
        case client_role_id = "client_role_id"
        case year = "year"
        case quarter = "quarter"
        case created_at = "created_at"
        case updated_at = "updated_at"
        case deleted_at = "deleted_at"
        case objective = "objective"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        mission = try values.decodeIfPresent(String.self, forKey: .mission)
        vision = try values.decodeIfPresent(String.self, forKey: .vision)
        type = try values.decodeIfPresent(Int.self, forKey: .type)
        client_role_id = try values.decodeIfPresent(Int.self, forKey: .client_role_id)
        year = try values.decodeIfPresent(String.self, forKey: .year)
        quarter = try values.decodeIfPresent(String.self, forKey: .quarter)
        created_at = try values.decodeIfPresent(String.self, forKey: .created_at)
        updated_at = try values.decodeIfPresent(String.self, forKey: .updated_at)
        deleted_at = try values.decodeIfPresent(String.self, forKey: .deleted_at)
        objective = try values.decodeIfPresent([PlanObjective].self, forKey: .objective)
    }

}
struct PlanObjective : Codable {
    let id : Int?
    let content_obj : String?
    let score : String?
    let project_id : String?
    let planning_id : Int?
    let created_at : String?
    let updated_at : String?
    let deleted_at : String?
    let plan_key_result : [Plan_key_result]?
    let major_action : [String]?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case content_obj = "content_obj"
        case score = "score"
        case project_id = "project_id"
        case planning_id = "planning_id"
        case created_at = "created_at"
        case updated_at = "updated_at"
        case deleted_at = "deleted_at"
        case plan_key_result = "key_result"
        case major_action = "major_action"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        content_obj = try values.decodeIfPresent(String.self, forKey: .content_obj)
        score = try values.decodeIfPresent(String.self, forKey: .score)
        project_id = try values.decodeIfPresent(String.self, forKey: .project_id)
        planning_id = try values.decodeIfPresent(Int.self, forKey: .planning_id)
        created_at = try values.decodeIfPresent(String.self, forKey: .created_at)
        updated_at = try values.decodeIfPresent(String.self, forKey: .updated_at)
        deleted_at = try values.decodeIfPresent(String.self, forKey: .deleted_at)
        plan_key_result = try values.decodeIfPresent([Plan_key_result].self, forKey: .plan_key_result)
        major_action = try values.decodeIfPresent([String].self, forKey: .major_action)
    }

}
struct Plan_key_result : Codable {
    let id : Int?
    let key_result : String?
    let metrics : String?
    let objective_id : Int?
    let created_at : String?
    let updated_at : String?
    let deleted_at : String?
    let type : Int?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case key_result = "key_result"
        case metrics = "metrics"
        case objective_id = "objective_id"
        case created_at = "created_at"
        case updated_at = "updated_at"
        case deleted_at = "deleted_at"
        case type = "type"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        key_result = try values.decodeIfPresent(String.self, forKey: .key_result)
        metrics = try values.decodeIfPresent(String.self, forKey: .metrics)
        objective_id = try values.decodeIfPresent(Int.self, forKey: .objective_id)
        created_at = try values.decodeIfPresent(String.self, forKey: .created_at)
        updated_at = try values.decodeIfPresent(String.self, forKey: .updated_at)
        deleted_at = try values.decodeIfPresent(String.self, forKey: .deleted_at)
        type = try values.decodeIfPresent(Int.self, forKey: .type)
    }

}
