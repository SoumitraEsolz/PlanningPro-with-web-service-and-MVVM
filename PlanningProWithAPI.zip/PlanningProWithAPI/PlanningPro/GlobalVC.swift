//
//  GlobalVC.swift
//  PlanningPro
//
//  Created by Soumitra MacBook on 20/06/21.
//

import UIKit
import Alamofire

struct Connectivity
{
    static let sharedInstance = NetworkReachabilityManager()!
    static var isConnectedToInternet:Bool
    {
        return self.sharedInstance.isReachable
    }
}

class GlobalVC: UIViewController {

    let FullWidth = UIScreen.main.bounds.size.width
    let FullHeight = UIScreen.main.bounds.size.height
    
    static var indicatorView = UIActivityIndicatorView()
    static var responseData: Data?
    static var responseError: Error?
    
    static let share = GlobalVC()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        GlobalVC.indicatorView.style = .large
        GlobalVC.indicatorView.color = .white
        GlobalVC.indicatorView.frame = self.view.frame
        GlobalVC.indicatorView.center = self.view.center
        GlobalVC.indicatorView.hidesWhenStopped = true
        
        self.view.addSubview(GlobalVC.indicatorView)
    }
    
    //MARK: - GetAPI Call
    func apiCall(urlString: String, method: HTTPMethod , headersStr: HTTPHeaders?, successCompletion: @escaping () -> (), failureCompletion: @escaping () -> ()) {
        
        if Connectivity.isConnectedToInternet {
            GlobalVC.indicatorView.startAnimating()
            
            AF.request(urlString, method: method, encoding: JSONEncoding.default, headers: headersStr).validate(statusCode: 200..<300)
                .responseData { response in
                    DispatchQueue.main.async {
                        GlobalVC.indicatorView.stopAnimating()
                    }
                    switch response.result {
                    case .success:
                        print("Validation Successful")
                        GlobalVC.responseData = response.data
                        successCompletion()
                        
                    case let .failure(error):
                        print(error)
                        GlobalVC.responseError = error
                        failureCompletion()
                        
                    }
                }
        }else{
            self.alertView(title: "Error!", message: "Network not available.")
        }
    }
    //MARK:- AlertView
    func alertView(title: String, message: String)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
        
        alert.addAction(okBtn)
        self.present(alert, animated: true, completion: nil)
    }
    

}
