//
//  PlanningVM.swift
//  PlanningPro
//
//  Created by Soumitra MacBook on 19/06/21.
//

import Foundation

struct PlanningResponseVM {
    private var response: PlanningResponseModel
    
    init(_ response: PlanningResponseModel) {
        self.response = response
    }
}
extension PlanningResponseVM{
    var status: Bool{
        return self.response.status!
    }
    var message: String{
        return self.response.message!
    }
    var code: Int{
        return self.response.code!
    }
    var planData: [PlanData]{
        return self.response.data!
    }
    
    func numberOfDataInSection() -> Int{
        return self.response.data!.count
    }
    func planDataAtSection(_ section: Int) -> PlanDataVM{
        let planData = self.response.data![section]
        return PlanDataVM(planData)
    }
}
struct PlanDataVM {
    private var dataResponse: PlanData
    
    init(_ dataResponse: PlanData) {
        self.dataResponse = dataResponse
    }
}
extension PlanDataVM{
    var id: Int{
        return self.dataResponse.id!
    }
    var role_name: String{
        return self.dataResponse.role_name!
    }
    var role_type: Int{
        return self.dataResponse.role_type!
    }
    var company: String{
        return self.dataResponse.company!
    }
    var colour: String{
        return self.dataResponse.colour!
    }
    var order: String{
        return self.dataResponse.order!
    }
    var user_id: Int{
        return self.dataResponse.user_id!
    }
    var created_at: String{
        return self.dataResponse.created_at!
    }
    var updated_at: String{
        return self.dataResponse.updated_at!
    }
    var deleted_at: String{
        return self.dataResponse.deleted_at!
    }
    var planning: Planning{
        return self.dataResponse.planning!
    }
    
}
struct PlanningVM {
    private var planResponse: Planning
    init(_ planResponse: Planning) {
        self.planResponse = planResponse
    }
}
extension PlanningVM{
    
    var id : Int{
        return self.planResponse.id!
    }
    var mission : String{
        return self.planResponse.mission!
    }
    var vision : String{
        return self.planResponse.vision!
    }
    var type : Int{
        return self.planResponse.type!
    }
    var client_role_id : Int{
        return self.planResponse.client_role_id!
    }
    var year : String{
        return self.planResponse.year!
    }
    var quarter : String{
        return self.planResponse.quarter!
    }
    var created_at : String{
        return self.planResponse.created_at!
    }
    var updated_at : String{
        return self.planResponse.updated_at!
    }
    var deleted_at : String{
        return self.planResponse.deleted_at!
    }
    var objective: [PlanObjective]{
        return self.planResponse.objective!
    }
    func planObjectDataAtIndex(_ index: Int) -> PlanObjectiveVM{
        let objectiveData = self.planResponse.objective![index]
        return PlanObjectiveVM(objectiveData)
    }
}
struct PlanObjectiveVM {
    private var objectiveResponse: PlanObjective
    
    init(_ objectiveResponse: PlanObjective) {
        self.objectiveResponse = objectiveResponse
    }
}
extension PlanObjectiveVM{

    var id: Int{
        return self.objectiveResponse.id!
    }
    var content_obj: String{
        return self.objectiveResponse.content_obj!
    }
    var score: String{
        return self.objectiveResponse.score!
    }
    var project_id: String{
        return self.objectiveResponse.project_id!
    }
    var planning_id: Int{
        return self.objectiveResponse.planning_id!
    }
    var created_at: String{
        return self.objectiveResponse.created_at!
    }
    var updated_at: String{
        return self.objectiveResponse.updated_at!
    }
    var deleted_at: String{
        return self.objectiveResponse.deleted_at!
    }
    var plan_key_result : [Plan_key_result]{
        return self.objectiveResponse.plan_key_result!
    }
    var major_action: [String]{
        return self.objectiveResponse.major_action!
    }
    
}
struct PlanKeyResultVM {
    private var keyResponse: Plan_key_result
    init(_ keyResponse: Plan_key_result) {
        self.keyResponse = keyResponse
    }
}
extension PlanKeyResultVM{
    var id: Int{
        return self.keyResponse.id!
    }
    var key_result: String{
        return self.keyResponse.key_result!
    }
    var metrics: String{
        return self.keyResponse.metrics!
    }
    var objective_id: Int{
        return self.keyResponse.objective_id!
    }
    var created_at: String{
        return self.keyResponse.created_at!
    }
    var updated_at: String{
        return self.keyResponse.updated_at!
    }
    var deleted_at: String{
        return self.keyResponse.deleted_at!
    }
    var type: Int{
        return self.keyResponse.type!
    }
}
