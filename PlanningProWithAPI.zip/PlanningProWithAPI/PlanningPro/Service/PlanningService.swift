//
//  PlanningService.swift
//  PlanningPro
//
//  Created by Soumitra MacBook on 19/06/21.
//

import Foundation
import Alamofire

protocol PlanningDataManagerDelegate {
    func didFetchPlanningData(_ manager: PlanningDataManager, response: PlanningResponseVM)
    func didFailWithError(error: Error)
}

struct PlanningDataManager{
    
    let planningURL:String = "http://planningpro.dedicateddevelopers.us/api/role/planning/0"
    
    var delegate: PlanningDataManagerDelegate?
    
    func fetchPlanningData() {
        
        let urlString = "\(planningURL)"
        
        performRequest(with: urlString)
    }
    
    func performRequest(with urlString: String) {
        
        let headers: HTTPHeaders = [
            "Content-Type":"application/json",
            "Accept":"application/json",
            "Authorization":"Bearer 739|c0DxqQa9nURCa2OSMMgxAdyEMdLre0JCscuXpTYz"
        ]
        
        GlobalVC.share.apiCall(urlString: urlString, method: .get, headersStr: headers) {
            if let safeData = GlobalVC.responseData {
                if let planData = self.parseJSON(safeData) {
                    
                    self.delegate?.didFetchPlanningData(self, response: planData)
                }
            }
        } failureCompletion: {
            self.delegate?.didFailWithError(error: GlobalVC.responseError!)
        }
    }
    
    func parseJSON(_ planData: Data) -> PlanningResponseVM? {
        let decoder = JSONDecoder()
        do {
            let decodedData = try decoder.decode(PlanningResponseModel.self, from: planData)
            
            let planData = PlanningResponseVM(decodedData)
            
            print(planData)
            
            return planData
            
        }catch{
            delegate?.didFailWithError(error: error)
            return nil
        }
    }
    
}
